OC DUEL v15 Netlify 배포용

이 폴더(또는 ZIP)를 Netlify에 배포하면 index.html이 자동으로 열립니다.
HTML을 Downloads에서 file:// 로 직접 열지 마세요. Firebase 온라인 기능은 http/https 환경에서 테스트해야 합니다.
